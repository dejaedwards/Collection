var CollectionList: [String] = ["Rings","rocks","incense","phone case","videogame skins","shoes","jewelry","bikes","lip gloss","lotion"]
print("Our collection list has \(CollectionList.count) items.")

CollectionList += ["Rings","rocks","incense","phone case","videogame skins","shoes","jewelry","bikes","lip gloss","lotion"]

CollectionList.append("Purses")

var FirstCollection = CollectionList[0]
var SecondCollection = CollectionList[1]
var ThirdCollection = CollectionList[2]
var FourthCollection = CollectionList[3]
var FifthCollection = CollectionList[4]
var SixthCollection = CollectionList[5]
var SeventhCollection = CollectionList[6]
var EighthCollection = CollectionList[7]
var NinthCollection = CollectionList[8]
var TenthCollection = CollectionList[9]

for collection in CollectionList {
    print(collection)
}
